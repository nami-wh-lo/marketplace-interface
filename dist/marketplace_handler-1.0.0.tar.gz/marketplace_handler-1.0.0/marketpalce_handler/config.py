class Settings:
    wb_api_url: str = "https://suppliers-api.wildberries.ru/"
    WB_ITEMS_REFRESH_LIMIT: int = 1000


settings = Settings()
